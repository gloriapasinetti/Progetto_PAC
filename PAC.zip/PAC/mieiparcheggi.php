<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />

<meta charset = "UTF-8"/>
<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

</head>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>
<body id="body">
<?php
include("intestazione_PAC.php");
?>

<main id='mainindex'>
	
	<div> <h2><b>I tuoi parcheggi</b></h2></div>
	<?php
	echo "<div id='contenitoremioprofilo'>
		<div id='menuaprire'><div id='ciao'><img src='immagini/menu.gif'></br>
		<span id='vocimenu'><a href='mioprofilo_PAC.php'>Mio Profilo</a></span></br>
		<span id='vocimenu'><a href='mierecensioni.php'>Recensioni</a></span></br>
		<span id='vocimenu'><a href='#'>Parcheggi</a></span></br></div></div>"
	?>
	
	<?php
	
	class parcheggio{
	public function mostra_parcheggio(){
		include("connessione.php");
		$idutente=$_SESSION['idutente'];
		$sql ="SELECT distinct nomeparcheggio, luogo, via from parcheggio as pa, prenotazione as p where pa.idparcheggio=p.idparcheggio and  p.idutente = " . $idutente;
		$ris = mysqli_query($conn, $sql);
		//$ris = mysqli_query($conn, $sql);
	
		while($riga=mysqli_fetch_array($ris)){
			echo $riga["nomeparcheggio"] . "<br/>" ;
			echo $riga["luogo"] . "<br/>";
			echo $riga["via"] . "<br/> </br>" ;
			
		}
		}
		
	}
	$parcheggio = new parcheggio;
	$parcheggio ->mostra_parcheggio();
	
	?>
</main>

<?php
include("footer_PAC.html");
?>
</body>
</html>