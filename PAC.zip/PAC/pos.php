<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<link rel="stylesheet" href="css/slide.css">
<meta charset = "UTF-8"/>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>


</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

<body>
<div id="contenitore" style="height:1700px;">
<?php
include("intestazione_PAC.php");
?>

<main id='mainindex'>
	<div>
	<div> <h2><b> <a href="parcheggi.php">Cerca il tuo parcheggio! </a></b></h2></div>
	<div>Lista parcheggi in ordine di vicinanza:</div></br></br>
	</div>
	<div id="test" >
	<?php
	include("connessione.php");
	$lat= $_POST["lat"];
	$lon = $_POST["lon"];
	//echo $lat . "</br>";
	//echo $lon;
	
	$sql= "SELECT idparcheggio, nomeparcheggio  from parcheggio where stato= 'A' order by 
	(latitudine-$lat),(longitudine-$lon) ;";
	$ris=mysqli_query($conn,$sql);
	while($riga= mysqli_fetch_array($ris)){
		echo "<div style='border:3px solid #760c0c; padding: 20px;'>";
		$idparcheggio = $riga["idparcheggio"]; 
		
		echo "<a href='prenota.php?idP=$idparcheggio'> - " . $riga["nomeparcheggio"] . "</br>";
		//echo $riga["longi"] . "</br>";
		echo "</div>";
	}
	
	
	?>
	</div>
</main>


<?php
include("footer_PAC.html");
?>
</div>
</body>
</html>


