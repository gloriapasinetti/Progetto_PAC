<html>
<?php
include("connessione.php");
session_start();
$rec = $_GET['recensione'];
$idutente=$_SESSION['idutente'];
$idP = $_GET['idP'];
$data = $_GET['data'];

$sql2="INSERT INTO recensioni(descrizione, data, idutente, idparcheggio) VALUES('$rec', '$data', '$idutente', '$idP')";			
		//$ris=mysqli_query($conn,$sql);
		//echo 'ok';
		header("location: mioprofilo_PAC.php?modifica=1");
		
?>
</html>