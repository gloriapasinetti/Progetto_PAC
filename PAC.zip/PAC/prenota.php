<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<link rel="stylesheet" href="css/slide.css">
<meta charset = "UTF-8"/>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>


</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

<body>
<div id="contenitore">
<?php
include("intestazione_PAC.php");
?>

<main id='mainindex'>
	<div>
	<div> <h2><b> <a href="parcheggi.php">Cerca il tuo parcheggio! </a></b></h2></div>
	<div>Lista parcheggi in ordine di vicinanza:</div></br></br>
	</div>
	<div id="test">
	<form name="prenota" action="conferma.php" method="post" >
	<?php
	include("connessione.php");
	$idP = $_GET["idP"];
	$sql = "SELECT nomeparcheggio, luogo, via, costo, numeroposti, postiliberi from parcheggio where idparcheggio =$idP";
	$ris=mysqli_query($conn,$sql);
	while($riga=mysqli_fetch_array($ris)){
		echo "IDParcheggio: <input type='text' name='idparcheggio' value=$idP readonly  style='text-align:center'> </input> </br></br>";
		echo  "Nome parcheggio: " . $riga["nomeparcheggio"] . "</br></br>";
		echo  "Luogo: " . $riga["luogo"] . "</br></br>";
		echo  "Via: ". $riga["via"] . "</br></br>";
		echo  "Costo: €". $riga["costo"] . "</br></br>";
		echo  "Posti: ". $riga["postiliberi"] . "/" .$riga["numeroposti"] . "</br></br>";
	};
	
	?>
	
	<input type="date" name="data"></input> </br></br>
	<input type="time" name="orario" > </input> </br></br>
	<label> Numero macchine: </label>
	<input type="text" name="posto" style="text-align:center;"> </input> </br></br></br>
	<input type="submit" value="Prenota" id="info "class="display"	style="font-size:18pt; font-family: 'Quicksand', sans-serif; padding:5px;width:200px;">
	</form>
	</div>
</main>


<?php
include("footer_PAC.html");
?>
</div>
</body>
</html>


