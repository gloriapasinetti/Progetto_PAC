<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<link rel="stylesheet" href="css/slide.css">
<meta charset = "UTF-8"/>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>


</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

<body>
<div id="contenitore">
<?php
include("connessione.php");
include("intestazione_PAC.php");
?>

<main id='mainindex'>
	<div>
	<?php
	
	if(!isset($_SESSION["idutente"])){
		echo "</br></br></br></br></br></br></br></br></br></br></br></br><div> <h1><b><a href='#win1' style=font-size:20px;>Iscriviti o effettua il Login per accedere al servizio di prenotazione dei parcheggi</a></b></h1></div>";
	}
	else{
		echo "<div> <h2><b> <a href='parcheggi.php'>Cerca il tuo parcheggio! </a></b></h2></div>
	<div>Questa piattaforma ti permetterà di trovare il parcheggio più adatto alle tue esigenze.</div></br></br>
	<div class='mappa'><div class='gmap_canvas'><iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d44590.1941688904!2d9.632070025148446!3d45.69323695428122!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47815111bc62ae73%3A0xd32fcb8f0be5a4d1!2sBergamo%20BG!5e0!3m2!1sit!2sit!4v1677833423817!5m2!1sit!2sit' width='600' height='450' style='border:0;' allowfullscreen='' loading='lazy' referrerpolicy='no-referrer-when-downgrade'></iframe>
	
	<a href='https://www.jetzt-drucken-lassen.de'></a></div><style>.mapouter{position:relative;text-align:right;height:300px;width:400px;}.gmap_canvas {overflow:hidden;background:none!important;height:300px;width:400px;}</style></div>

	";

	}
	?>
	
	
	<a  class="overlay" id="win1"></a>

	<div class="popup">

	<form action = "accessologin.php" method = "post" id = "login">

	<span id="titolo">Inserisci le tue credenziali</span></br>

	<a id="errore">Credenziali errate</a></br>

	<span>Username:</span> <input type = "email" name = "username"></br>
	<span>Password:</span> <input type = "password" name = "password"></br>
	<input type = "submit" value = "Login" style="font-size:12pt;"></br></br></br>

	<span id="noaccount">Non hai un account?</span> <a href="registrazione.php"> Registrati </a>

	<a class="close" title="Chiudere" href="<?php echo $_SERVER["PHP_SELF"]."?#close"; ?>" ></a>
</form>
	</div>
</main>


<?php
include("footer_PAC.html");
?>
</div>
</body>
</html>
