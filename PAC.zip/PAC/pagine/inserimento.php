<html>
<head>
<title> Inserimento </title>
</head>
<body>


<?php
class inserimentoUtente{
	public function nuovoUtente(){
		include("connessione.php");

		$cognome=$_POST["cognome"];
		$nome=$_POST["nome"];
		$indirizzo=$_POST["indirizzo"];
		$idprovincia=$_POST["provincia"];
		$citta=$_POST["citta"];
		$username=$_POST["mail"];
		$password=$_POST["password"];
		$password2=$_POST["password2"];
		
		$sql="SELECT idcitta FROM comuni WHERE nomecitta='$citta'";
		
		$ris=mysqli_query($conn,$sql);
	
		$riga= mysqli_fetch_array($ris);
		$idcitta=$riga["idcitta"];
		
		if ($password==$password2) {
		$sql= "INSERT INTO utenti(cognome, nome, indirizzo, idcitta, idprovincia, username, password) VALUES('$cognome', '$nome', '$indirizzo', $idcitta, '$idprovincia', '$username', '$password')";
			
		echo $sql;
		
		if (mysqli_query($conn, $sql)) {
			$sql = "SELECT idutente, nome, cognome, username From utenti Where username = '$username' AND password = '$password'";
			$ris = mysqli_query($conn, $sql);
			$riga = mysqli_fetch_array($ris);
			$idutente = $riga["idutente"];
			$username = $riga["username"];
			$nome = $riga["nome"];
			$cognome = $riga["cognome"];
			session_start();
	
			$_SESSION['idutente'] = $idutente;
			$_SESSION['username'] = $username;
			$_SESSION['nome'] = $nome;
			$_SESSION['cognome'] = $cognome;
			
			header("location: index.php");
		}
		else{
			header("location: registrazione.php?e=0");
		}}
		
		else {echo ("LE PASSWORD NON CORRISPONDONO!");}
	
	mysqli_close($conn);
	}
}	
		$utente = new inserimentoUtente;
		$utente -> nuovoUtente();
	
		
?>
	
</body>
</html>