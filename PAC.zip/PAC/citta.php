<?php

		include ("connessione.php");

		$prov=$_POST["provincia"];
		 
		$sql="SELECT nomecitta FROM comuni WHERE idprovincia='" . $prov . "'";

		$ris=mysqli_query($conn, $sql);
		$str="";
			
			while ($riga=mysqli_fetch_array($ris)){	
				$str .= $riga["nomecitta"] . "-";
			}
		
		mysqli_close($conn);	

		$str=substr($str, 0, -1);

		echo $str;

 
?>