<html>
<head>
<title>Sito Parcheggio</title>
<link rel="stylesheet" href="../css/stile.css">
<link rel="stylesheet" href="../css/serviziocss.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<meta charset = "UTF-8"/>
</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Lobster');
</style>
<style>
@import url('https://fonts.googleapis.com/css?family=Bangers');
</style>

<body>

<div id="contenitore">

<?php
include("intestazione.php");
?>

<div id="corpo2">
	
	<form name="login" action="accessologin.php" method="post" class="frmlogin">
			<p>Inserisci le tue credenziali per accedere:</p></br> </br>
			<label for="username" class="display"> Username </label>
			<input type="text" name="username" id="username" required style="font-size:18pt; margin-left:25px;">  </br> </br>
			
			<label for="password" class="display"> Password </label>
			<input type="password" name="password" id="password" required style="font-size:18pt; margin-left:25px;">  </br> </br>
						
			<input type="submit" value="Accedi" class="display" style="font-size:18pt;">
	</form>
	
</div>

<?php
include("footer.php");

if (isset($_GET["e"])){
		echo "<script type='text/javascript'>alert('ERRORE DURANTE IL LOGIN');</script>";
	}
?>
</div>
</body>
</html>