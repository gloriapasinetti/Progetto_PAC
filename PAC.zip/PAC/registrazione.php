<html>
<head>
<title>Sito Parcheggio</title>
<link rel="stylesheet" href="css/css_PAC.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<meta charset = "UTF-8"/>
<script type="text/javascript" src="jquery-3.3.1.min.js"></script>
</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>



<script>
   
$(document).ready(function(){

 $("#cmbprovincia").change(function(){
   $("#cmbcitta").empty()
 });
  
   $("#cmbprovincia").change(function(){
    var cmbprov = document.getElementById("cmbprovincia").value;
    
    
    $.ajax({
     url: 'citta.php',
     type: 'POST',
     data: "provincia=" + cmbprov,
     success: function(data) {
     
       var str = data;
       var res = str.split("-");
         var lung = res.length;        
       for(var j=0;j<lung;j++){
        $("#cmbcitta").append("<option>" + res[j] + "</option>")
       
         }
        
        document.getElementById("info").innerHTML = str;
        
        },
     error: function(){      
       document.getElementById("info").innerHTML = "Aggiornamento non eseguito. Verificare la connessione" ;
       
       }
     }); 
     
   });
    
 });


function controlla() {
	var cognome = document.getElementById("cognome").value;
	var nome = document.getElementById("nome").value;
	var mail = document.getElementById("mail").value;
	var username = document.getElementById("username").value;
	var password = document.getElementById("password").value;
	var password2 = document.getElementById("password2").value;
	
	if (cognome == " " && nome == " "){
		alert("Nome o cognome vuoti. Riempi il campo mancante");
		return false;
	}
		
	if (username == " "){
		alert("Username vuoto. Riempire il campo mancante");
		return false;
	}
	
	if (email(mail) == false){
		alert("EMAIL NON CORRETTA");
		document.getElementById("mail").value = "";
		return false;
	}
	if (password.length < 8){
		alert("LA PASSWORD DEVE CONTENERE ALMENO 8 CARATTERI");
		document.getElementById("password").value = "";
		document.getElementById("passwor2").value = "";
		return false;
	}
	if (password != password2){
		alert("LE DUE PASSWORD NON CORRISPONDONO");
		document.getElementById("password2").value = "";
		return false;
	}	
}
function email(mail){
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	if (reg.test(mail) == false) { return (false); } 
}
</script>

<body>

<div id="contenitore">

<?php
include("intestazione_PAC.php");
?>

<main id="mainindex">
	<div style=" text-align:center;">
	<form name="login" action="inserimento.php" method="post" class="frmlogin">
			<p>Inserisci le tue credenziali per accedere:</p></br> </br>
			
			
			<label for="cognome" class="display"> Cognome </label>
			<input type="text" name="cognome" style="font-size:18pt; margin-left:25px;">  </br> </br>
			
			<label for="nome" class="display"> Nome </label>
			<input type="text" name="nome" style="font-size:18pt; margin-left:25px;">  </br> </br>
			
			<?php
			include("connessione.php");
			$sql= "SELECT idprovincia, nomeprovincia FROM province";
			$ris= mysqli_query($conn, $sql);		
			?>
			<label for="provincia" class="display"> Provincia </label>
			<select id="cmbprovincia" name="provincia" style="width:275px; font-size:18pt; margin-left:25px;" >
			<option> </option>
			<?php
				while($riga=mysqli_fetch_array($ris)) {
					echo "<option value=". $riga["idprovincia"] . ">" . $riga["nomeprovincia"] .  "</option>";
				}
			?>
			</select> 
			
			<label for="citta" class="display" style="margin-left:50px;"> Città </label>
			<select id="cmbcitta" name="citta" style="width:275px;font-size:18pt;">

			</select> </br> </br>
			
			<label for="indirizzo" class="display"> Indirizzo </label>
			<input type="text" name="indirizzo" style="font-size:18pt; ">  </br> </br>
			
			<label for="mail" class="display"> Mail </label>
			<input type="text" name="mail" style="font-size:18pt; ">  </br> </br>
			
			<label for="password" class="display"> Password </label>
			<input type="password" name="password" style="font-size:18pt; ">  </br> </br>
			
			<label for="password2" class="display"> Conferma password </label>
			<input type="password" name="password2" style="font-size:18pt; ">  </br> </br>
			
			<input type="submit" value="Registrati" id="info "class="display" onclick="controlla()" style="font-size:18pt; padding:5px;width:200px;">
	</form>
	</div>
</main>

<?php
include("footer_PAC.html");
?>
</div>
</body>
</html>