<html>
<style>
* {box-sizing:border-box}

.slideshow-container {
  max-width:1600px;
  max-height:650px;
  position: relative;
  margin: auto;
}

.mySlides {
  display: none;
}

.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  margin-top: -22px;
  padding: 16px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
}

.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}


.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

.active, .dot:hover {
  background-color: #717171;
}

.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
} 
</style>
<header>
<div id="contenitore">
		<a href="index.php"></a>
		
		<nav>
		<ul>
			
			<li><a href='index.php'>Home</a></li>
			<li><a href="faq.php">FAQ</a></li>
			<?php
			class intestazione{
			public function visIntestazione(){
				session_start();
				if(!isset($_SESSION["idutente"])){
					echo "<li><a href='#win1'>Login</a></li>";}
				else{
					$nome = $_SESSION['nome'];
					//$cognome=$_SESSION['cognome'];
					echo "<li><a href='logout.php' >Logout</a></li>";//per far aprire il popup del logout
					if($nome != "Amministratore"){
						echo "<li><a href='mioprofilo_PAC.php'>Ciao ". $nome ."</a></li>";
						}
				}
				}
			}
			$intestazione = new intestazione;
			$intestazione -> visIntestazione();

			?>
			
		</ul>
	</nav>
	
	<div class="slideshow-container">
	
  <div class="mySlides fade">
    <img src="immagini/PARK1.jpg" style="width:1200px; height:500px;">
  </div>
  
  <div class="mySlides">
    <img src="immagini/PARK2.jpg" style="width:1200px; height:500px;">
  </div>

  <div class="mySlides fade">
    <img src="immagini/PARK3.jpg" style="width:1200px; height:500px;">
  </div>

  

  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none"; 
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1} 
  slides[slideIndex-1].style.display = "block"; 
  setTimeout(showSlides, 5000); 
} 
</script>
	
	
	
	
	
	
	
	
	
	<?php
		if(isset($_GET["errore"])){
			$errore=$_GET["errore"];
			if($errore==1){
				echo "<style> .popup #errore {visibility:visible;}</style>";}
		}
	
	?>

<a  class="overlay" id="win1"></a>

	<div class="popup">

	<form action = "accessologin.php" method = "post" id = "login">

	<span id="titolo">Inserisci le tue credenziali</span></br>

	<a id="errore">Credenziali errate</a></br>

	<span>Username:</span> <input type = "email" name = "username"></br>
	<span>Password:</span> <input type = "password" name = "password"></br>
	<input type = "submit" value = "Login" style="font-size:12pt;"></br></br></br>

	<span id="noaccount">Non hai un account?</span> <a href="registrazione.php"> Registrati </a>

	<a class="close" title="Chiudere" href="<?php echo $_SERVER["PHP_SELF"]."?#close"; ?>" ></a>
</form>



</div>
</div>
</header>
