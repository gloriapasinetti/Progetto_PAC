<html>
<head>
<title>Accesso</title>
<meta charset="UTF-8">
<link href="css/style.css" rel="stylesheet" type="text/css" >
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
</head>
<body>
<div id="contenitore">
		<?php
		include ("intestazione_PAC.php");
		?>
<div id="corpo">
<?php
include("connessione.php");
	
	$username=$_POST["username"];
	$password=$_POST["password"];
	
		$sql="SELECT idutente from utenti where username='$username' and password='$password'";
		
		$ris=mysqli_query($conn,$sql);
		$righe=mysqli_num_rows($ris);
		
		
	if($righe==1){
		$sql = "SELECT idutente, cognome, nome, username  From utenti Where username = '$username' and password = '$password'";
		$ris = mysqli_query($conn, $sql);
		$riga = mysqli_fetch_array($ris);
		$idutente = $riga["idutente"];
		$username = $riga["username"];
		$nome = $riga["nome"];
		$cognome = $riga["cognome"];
		
		
	session_start();
	$_SESSION['idutente'] = $idutente;
	$_SESSION['username'] = $username;
	$_SESSION['nome'] = $nome;
	$_SESSION['cognome'] = $cognome;
	
	header("location: index.php");
	//echo "<a class='login' href='ordine.php'>Ciao " . $nome . " " . $cognome ."</a>";}
}
else{
	header("location: login.php?e=0");
	}
?>
</div>
	<?php
		include ("footer.php");
	?>
	</div>
	</body>
</html>