

<html>
</head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<link rel="stylesheet" href="css/slide.css">
<meta charset = "UTF-8"/>
<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>
<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
</head>

</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');

</style>
<body >

<?php
include("connessione.php");
include("intestazione_PAC.php");
?>
<main id='mainfaq'>
<div id = "faq">
<h1>  Ecco le risposte alle domande più frequenti!</h1>

<div>
	<div class='domandad' style="font-size:17pt;
	font-weight:bold;
	height:50px;
	width:100%;
	text-align:right;
	margin-right:50px;
	margin-top:50px;"><img src="immagini/romboelenco.gif"> Come posso iscrivermi?</div>
	<div class='risposta' style ="font-size:12pt;
	height:40px;
	width:90%;
	text-align:left;
padding-left:60px;"> Per iscriverti è sufficiente cliccare sul link con la voce "Iscriviti" nella pagina iniziale e successivamente inserire i tuoi dati personali</div>
</div>
<div>
	<div class='domandas' style ="font-size:17pt;
	font-weight:bold;
	height:50px;
	width:100%;
	text-align:left;
	margin-left:50px;
	margin-top:50px;"><img src="immagini/romboelenco.gif"> Come posso vedere i parcheggi aperti vicino a me?</div>
	<div class='risposta' style ="font-size:12pt;
	height:40px;
	width:90%;
	text-align:left;
padding-left:60px;">Per farlo bisogna inserire le coordinate della propria posizione e premere il tasto di ricerca, ma è necessario essere loggati.</div>
</div>
<div>
	<div class='domandad'style="font-size:17pt;
	font-weight:bold;
	height:50px;
	width:100%;
	text-align:right;
	margin-right:50px;
	margin-top:50px;"><img src="immagini/romboelenco.gif"> Come posso inserire una recensione?</div>
	<div class='risposta' style ="font-size:12pt;
	height:40px;
	width:90%;
	text-align:left;
padding-left:60px;">Dopo aver effettuato la prenotazione del parcheggio è possibie lasciare una recensione.</div>
</div>
<div>
	<div class='domandas' style ="font-size:17pt;
	font-weight:bold;
	height:50px;
	width:100%;
	text-align:left;
	margin-left:50px;
	margin-top:50px;"><img src="immagini/romboelenco.gif"> E' possibile prenotare per più macchine?</div>
	<div class='risposta'style ="font-size:12pt;
	height:40px;
	width:90%;
	text-align:left;
padding-left:60px;">Si, quando si sceglie il parcheggio bisogna inserire il numero di auto per cui si vuole prenotare.</div>
</div>
<div>
	<div class='domandad' style="font-size:17pt;
	font-weight:bold;
	height:50px;
	width:100%;
	text-align:right;
	margin-right:50px;
	margin-top:50px;"><img src="immagini/romboelenco.gif"> Il pagamento va effettuato alla prenotazione del parcheggio?</div>
	<div class='risposta' style ="font-size:12pt;
	height:40px;
	width:90%;
	text-align:left;
padding-left:60px;"> No, il parcheggio verrà pagato dopo la permanenza presso il parcheggio stesso.</div>
</div>
</main>

<?php
include("footer_PAC.html");
?>

</body>
</html>