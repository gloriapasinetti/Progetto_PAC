<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<link rel="stylesheet" href="css/slide.css">
<meta charset = "UTF-8"/>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>


</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

<body>
<div id="contenitore">
<?php
include("intestazione_PAC.php");
?>

<main id='mainindex'>
	<div>
	<div> <h2><b> <a href="parcheggi.php">Cerca il tuo parcheggio! </a></b></h2></div>
	<div>Conferma:</div></br></br>
	</div>
	<div id="test">
	
	<?php
	include("connessione.php");

	
	$posti=$_POST["posto"];
	$idP=$_POST["idparcheggio"];
	$idutente=$_SESSION['idutente'];
	$data=$_POST["data"];
	$orario=$_POST["orario"];
	
	$sql = "select postiliberi from parcheggio where idparcheggio =$idP";
	$ris=mysqli_query($conn,$sql);
	$riga=mysqli_fetch_array($ris);
	if($posti <= $riga["postiliberi"]){
		$sql="update parcheggio set postiliberi= postiliberi-$posti where idparcheggio=$idP";
		$ris=mysqli_query($conn,$sql);
		
		$sql="insert into prenotazione(data, orario, numeroAuto, idparcheggio, idutente) values('$data','$orario','$posti','$idP','$idutente')";
		$ris=mysqli_query($conn,$sql);
		//$riga=mysqli_fetch_array($ris2);
		//echo $data;
		echo "<h2> PRENOTAZIONE EFFETTUATA!</h2> </br> </br>" ;
		
		echo "<a href=rec.php?idP=$idP&data=$data style='font-size:23px'> Lascia una recensione </a></br>";
		echo "<img src='immagini/rec.jpg'> </br> </br>"; 
		
	
		
	}
	?>
	<form name = "recensio" action="rec.php" method = "post">
	<input type= 'text' name ='recensione'> </input>
	</form>
	</div>
</main>


<?php
include("footer_PAC.html");
?>
</div>
</body>
</html>