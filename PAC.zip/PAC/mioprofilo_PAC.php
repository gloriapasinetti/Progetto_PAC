<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<meta charset = "UTF-8"/>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
<!-- End WOWSlider.com HEAD section -->
<script>
$(document).ready(function(){
$("#cmbProvincia").change(function(){
	$("#cmbCitta").empty()
});
$("#cmbProvincia").change(function(){
	var cmbProv = document.getElementById("cmbProvincia").value;
		$.ajax({
			url: 'citta.php',
			type: 'POST',
			data: "provincia=" + cmbProv,
			success: function(data) {
				var str = data;
				var res = str.split("|");
				var lung = res.length;	
				
				for(var j=0;j<lung;j++){
				var ress = res[j].split("-");				
				
					$("#cmbCitta").append("<option value='" + ress[0]+"'>" + ress[1]+"</option>")
				}
				document.getElementById("info").innerHTML = str;
			},
			error: function(){						
				document.getElementById("info").innerHTML = "Aggiornamento non eseguito. Verificare la connessione" ;
			}
		});
					
});


});
</script>	
</head>
<body>
<?php
include("intestazione_PAC.php");
include("connessione.php");
?>
<main id="mainmieicorsi" style = "text-align: center; padding: 20px;">
<?php
if(!isset($_SESSION["idutente"])){
if(!isset($_GET["pippo"])){
header("location:". $_SERVER["PHP_SELF"]."?pippo=1&#win");}
?>

<a class="overlay" id="win"></a>
	<div class="popup">
	<form action = "accessologin.php" method = "post" id = "login">
	<span id="titolo">Per accedere a questa pagina devi essere registrato</br></br>Inserisci qui le tue credenziali</span></br>
	<a id="errore">Credenziali errate</a></br>
	<span>Username:</span> <input type = "email" name = "username" ></br>
	<span>Password:</span> <input type = "password" name = "password" ></br>
	<input type = "submit" value = "Login" style="font-size:12pt;"></br></br></br>
	<span id="noaccount">Non hai un account?</span> <a href="registrazione.php"> Registrati </a></form></div>

<?php 
}
else{
$idutente=$_SESSION['idutente'];
$sql="Select cognome, nome, indirizzo, idcitta, idprovincia from utenti where idutente=" . $idutente;


$ris = mysqli_query($conn, $sql);
	while($riga=mysqli_fetch_array($ris)){
		$sqll="select nomeprovincia from province where idprovincia='" . $riga["idprovincia"] . "'";
			$riss = mysqli_query($conn, $sqll);
			$prov=mysqli_fetch_array($riss);
		$sqlll="select nomecitta from comuni where idcitta='" . $riga["idcitta"] . "'";
			$risss = mysqli_query($conn, $sqlll);
			$comune=mysqli_fetch_array($risss);

	echo "
	<form id='formmioprofilo' action='salvamodificheprofilo.php' method='post'>
	<div id='contenitoremioprofilo' style='margin-top:150px;'>
	
		<div id='menuaprire'><div id='ciao'><img src='immagini/menu.gif'></br>
		<span id='vocimenu'><a href='#'>Mio Profilo</a></span></br>
		<span id='vocimenu'><a href='mierecensioni.php'>Recensioni</a></span></br>
		<span id='vocimenu'><a href='mieiparcheggi.php'>Parcheggi</a></span></br></div></div>
		
		<h2 style='margin-top:100px;'>" . $riga["nome"] . " " . $riga["cognome"] . "</h2> </br></br></br>
		<div id='infoutente5' >
			<span > Cognome:</span><input name='cognome' type='text' value='" . $riga["cognome"] . "' style='margin-left:20px;'></p></br></br></br>
			<span >Nome:</span><input name='nome' type='text' value='" . $riga["nome"] . "'style='margin-left:20px;'></br></br></br>
			<span >Indirizzo:</span><input name='indirizzo' type='text' value='" . $riga["indirizzo"] . "' style='margin-left:20px;'></br></br></br>";
	
	//PROVINCE
	$sqltutteprovince="select * from province";
	$riss=mysqli_query($conn,$sqltutteprovince);
	mysqli_set_charset($conn,"utf8");
	echo "<span>Provincia:</span><select id='cmbProvincia' name='cmbProvincia' required style='margin-left:20px;'><option value='". $riga["idprovincia"] . "' selected>" . $prov["nomeprovincia"] . " </option>";
	while($rigaa=mysqli_fetch_array($riss)){
		echo "<option value='" . $rigaa["idprovincia"] . "'>" . $rigaa["nomeprovincia"] . "</option>";
	}
	echo "</select></br></br></br>";
	
	
	//COMUNE
	$sqlcomune="select * from comuni where idprovincia='" . $riga["idprovincia"] . "'";
	$riss=mysqli_query($conn,$sqlcomune);
	mysqli_set_charset($conn,"utf8");
	echo "<span>Comune:</span><select id='cmbCitta' name='cmbCitta' style='margin-left:20px;'><option value='". $riga["idcitta"] . "' selected>" . $comune["nomecitta"] . "</option>";
	while($rigaa=mysqli_fetch_array($riss)){
		echo "<option value='" . $rigaa["idcitta"] . "' >" . $rigaa["nomecitta"] . "</option>";
	}
	echo "</select></br>";
	
	echo "</div></br></br></br>";
	
	
	echo "<div><input type='submit' id='bottonesalvamodificaprofilo' value='SALVA MODIFICHE' style='font-size:18pt; font-family: 'Quicksand', sans-serif; padding:5px;width:200px;'></div></br>";
	if(isset($_GET["modifica"])){
		echo "<div><label id='modificacorretta'>Modifica avvenuta correttamente!</label></div></form>";
	}
	echo "</div></form>";
	}
	

}



?>
</main>
<?php
include("footer_PAC.html");
?>
</body>
</html>