
<?php
		$hostname= "localhost";
		$username= "root";
		$password= "usbw";
		$dbase= "dbparcheggi";
		
		$conn= mysqli_connect($hostname, $username, $password, $dbase);
		mysqli_set_charset($conn, "utf8");
?>