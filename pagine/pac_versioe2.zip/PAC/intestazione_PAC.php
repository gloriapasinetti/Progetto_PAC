<html>
<header>
<div id="contenitore">
		<a href="index.php"></a>
		
		<nav>
		<ul>
			
			<li><a href='index.php'>Home</a></li>
			<li><a href="faq.php">FAQ</a></li>
			<?php
			class intestazione{
			public function visIntestazione(){
				session_start();
				if(!isset($_SESSION["idutente"])){
					echo "<li><a href='#win1'>Login</a></li>";}
				else{
					$nome = $_SESSION['nome'];
					//$cognome=$_SESSION['cognome'];
					echo "<li><a href='logout.php' >Logout</a></li>";//per far aprire il popup del logout
					if($nome != "Amministratore"){
						echo "<li><a href='mioprofilo_PAC.php'>Ciao ". $nome ."</a></li>";
						}
				}
				}
			}
			$intestazione = new intestazione;
			$intestazione -> visIntestazione();

			?>
			
		</ul>
	</nav>
	<?php
		include("slide.php");
		?>
	<?php
		if(isset($_GET["errore"])){
			$errore=$_GET["errore"];
			if($errore==1){
				echo "<style> .popup #errore {visibility:visible;}</style>";}
		}
	
	?>

<a  class="overlay" id="win1"></a>

	<div class="popup">

	<form action = "accessologin.php" method = "post" id = "login">

	<span id="titolo">Inserisci le tue credenziali</span></br>

	<a id="errore">Credenziali errate</a></br>

	<span>Username:</span> <input type = "email" name = "username"></br>
	<span>Password:</span> <input type = "password" name = "password"></br>
	<input type = "submit" value = "Login" style="font-size:12pt;"></br></br></br>

	<span id="noaccount">Non hai un account?</span> <a href="registrazione.php"> Registrati </a>

	<a class="close" title="Chiudere" href="<?php echo $_SERVER["PHP_SELF"]."?#close"; ?>" ></a>
</form>



</div>
</div>
</header>
