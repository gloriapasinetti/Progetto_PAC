<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<link rel="stylesheet" href="css/slide.css">
<meta charset = "UTF-8"/>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>

</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

<body>
<div id="contenitore">
<?php
include("intestazione_PAC.php");
?>

<main id='mainindex'>

	<div>
	<div> <h2><b>Parcheggi</b></h2></div>
	<div>Questa piattaforma ti permetterà di trovare il parcheggio più adatto alle tue esigenze.</div></br></br>
	<button onclick="trovaCoordinate()">Trova la tua posizione</button> </br>
	<p  id="lat">Latitudine: </p>
	<p  id="lon">Longitudine: </p>
	<form name="geo" action="pos.php" method="post" >
	<label> Copia latitudine: </label>
	<input type="text" name="lat"> </input> </br>
	<label> Copia longitudine: </label>
	<input type="text" name="lon">  </input> </br>
	<input type="submit" value="cerca" id="info "class="display" onclick="controlla()" style="font-size:18pt; padding:5px;width:200px;">
	
	</div>
	</main>

<script type="text/javascript">
	var x = document.getElementById("test");

function trovaCoordinate() {
if (navigator.geolocation) {
navigator.geolocation.getCurrentPosition(showPosition);
} else {
x.innerHTML = "Geolocalizzazione non supportata dal browser.";
}
}
function showPosition(position) {
	var lat;
	var lon;
	var distanzaLat;
	var distzanLon;
	lat = position.coords.latitude;
	lon = position.coords.longitude;
	document.getElementById("lat").innerHTML = lat ;
	document.getElementById("lon").innerHTML = lon ;
							
}
</script>
</form>
</main>



<?php
include("footer_PAC.html");
?>
</div>
</body>
</html>
