<html>
<div class="slideshow-container">

  <div class="mySlides">
    <img src="immagini/foto2.jpg" style="width:100%">
  </div>

  <div class="mySlides fade">
    <img src="immagini/foto3.jpg" style="width:100%">
  </div>

  <div class="mySlides fade">
    <img src="immagini/foto1.jpg" style="width:100%">
  </div>
  
  <div class="mySlides fade">
    <img src="immagini/foto4.jpg" style="width:100%">
  </div>
  
  <div class="mySlides fade">
    <img src="immagini/foto5.jpg" style="width:100%">
  </div>

  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none"; 
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1} 
  slides[slideIndex-1].style.display = "block"; 
  setTimeout(showSlides, 5000); 
} 
</script>
</html>