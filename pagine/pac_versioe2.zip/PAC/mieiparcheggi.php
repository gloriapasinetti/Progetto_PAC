<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />

<meta charset = "UTF-8"/>
<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

</head>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>
<body id="body">
<?php
include("intestazione_PAC.php");
?>

<main id='mainindex'>
	
	<div> <h2><b>I tuoi parcheggi</b></h2></div>
	<?php
	echo "<div id='contenitoremioprofilo'>
		<div id='menuaprire'><div id='ciao'><img src='immagini/menu.gif'></br>
		<span id='vocimenu'><a href='mioprofilo_PAC.php'>Mio Profilo</a></span></br>
		<span id='vocimenu'><a href='mierecensioni.php'>Recensioni</a></span></br>
		<span id='vocimenu'><a href='#'>Parcheggi</a></span></br></div></div>"
	?>
	<div class="mappa"><div class="gmap_canvas"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11153.31522815228!2d9.74266!3d45.6642991!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x206a1c6e79735308!2sORIO.20%20PARKING!5e0!3m2!1sit!2sit!4v1674651541629!5m2!1sit!2sit" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
 <a href="https://www.jetzt-drucken-lassen.de"></a></div><style>.mapouter{position:relative;text-align:right;height:300px;width:400px;}.gmap_canvas {overflow:hidden;background:none!important;height:300px;width:400px;}</style></div>
	
	<?php
	
	class parcheggio{
	public function mostra_parcheggio(){
		include("connessione.php");
		$idutente=$_SESSION['idutente'];
		$sql ="SELECT nomeparcheggio, luogo, via from parcheggio as pa, prenotazione as p where pa.idparcheggio=p.idparcheggio and  p.idutente = " . $idutente;
		$ris = mysqli_query($conn, $sql);
		//$ris = mysqli_query($conn, $sql);
	
		while($riga=mysqli_fetch_array($ris)){
			echo $riga["nomeparcheggio"] . "<br/>" ;
			echo $riga["luogo"] . "<br/>";
			echo $riga["via"] . "<br/> </div>" ;
			
		}
		}
	}
	$parcheggio = new parcheggio;
	$parcheggio ->mostra_parcheggio();
	
	?>
</main>


	


<footer id="pie1">
<p>Cosa stai cercando?</p></br>



</footer>

<?php
include("footer_PAC.html");
?>
</body>
</html>