
<html lang="it">
<head>
<!-- meta tags -->
<meta charset="utf-8">
</head>

<body>
<p>Trova le tue Coordinate</p>
<button onclick="trovaCoordinate()">Trova la tua posizione</button>
<p id="test"></p>

<script type="text/javascript">
var x = document.getElementById("test");

function trovaCoordinate() {
if (navigator.geolocation) {
navigator.geolocation.getCurrentPosition(showPosition);
} else {
x.innerHTML = "Geolocalizzazione non supportata dal browser.";
}
}
function showPosition(position) {
x.innerHTML = "Latitudine: " + position.coords.latitude +
"<br>Longitudine: " + position.coords.longitude;
}
</script>

</body>
</html>