<html>
<head>
<link href = "css/css_PAC.css" rel="stylesheet" type = "text/css" />
<link rel="stylesheet" href="css/slide.css">
<meta charset = "UTF-8"/>
<script type="text/javascript" src="https://nibirumail.com/docs/scripts/nibirumail.cookie.min.js"></script>


</head>

<style>
@import url('https://fonts.googleapis.com/css?family=Quicksand');
</style>

<body>
<div id="contenitore">
<?php
include("intestazione_PAC.php");
?>

<main id='mainindex'>
	<div>
	<div> <h2><b> <a href="parcheggi.php">Cerca il tuo parcheggio! </a></b></h2></div>
	<div>Questa piattaforma ti permetterà di trovare il parcheggio più adatto alle tue esigenze.</div></br></br>
	</div>
</main>


<?php
include("footer_PAC.html");
?>
</div>
</body>
</html>
