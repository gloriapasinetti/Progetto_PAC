<?php
include("connessione.php");
session_start();
$idutente=$_SESSION["idutente"];

	$cognome=$_POST["cognome"];
	$nome=$_POST["nome"];
	$indirizzo = $_POST["indirizzo"];
	$provincia=$_POST["cmbProvincia"];
	$comune=$_POST["cmbCitta"];
	mysqli_set_charset($conn,"utf8");
	$sql="UPDATE utenti SET cognome='" . $cognome . "', nome='" . $nome . "', indirizzo='" .$indirizzo . "', idcitta='" . $comune ."', idprovincia='" . $provincia . "' WHERE idutente='" . $idutente . "'";
	$ris=mysqli_query($conn,$sql);
	header("location: mioprofilo_PAC.php?modifica=1");

?>